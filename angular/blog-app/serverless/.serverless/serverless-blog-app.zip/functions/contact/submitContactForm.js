const { v4: uuidv4 } = require('uuid');
const dynamodb = require('../../utils/dynamodb');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const { name, email, message } = JSON.parse(event.body);

    const contact = {
      id: uuidv4(),
      name,
      email,
      message,
      createdAt: new Date().toISOString()
    };
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `ContactSubmissions-${stage}`,
      Item: contact
    };

    await dynamodb.put(params).promise();

    return response(201, { message: 'Contact form submitted successfully' });
  } catch (error) {
    console.error('Error submitting contact form:', error);
    return response(500, { message: 'Error submitting contact form' });
  }
};