const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user || user.role !== 'admin') {
      return response(403, { message: 'Not authorized' });
    }
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `ContactSubmissions-${stage}`
    };

    const result = await dynamodb.scan(params).promise();
    return response(200, result.Items);
  } catch (error) {
    console.error('Error fetching contact submissions:', error);
    return response(500, { message: 'Error fetching contact submissions' });
  }
};