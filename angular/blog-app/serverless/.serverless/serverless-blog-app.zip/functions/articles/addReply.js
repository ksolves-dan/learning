const { v4: uuidv4 } = require('uuid');
const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);
    
    if (!user) {
      return response(401, { message: 'Not authorized' });
    }

    const { articleId, commentId } = event.pathParameters;
    const { content } = JSON.parse(event.body);

    const stage = process.env.STAGE || 'dev';
    const getParams = {
      TableName: `Articles-${stage}`,
      Key: { id: articleId }
    };

    const article = await dynamodb.get(getParams).promise();
    
    if (!article.Item) {
      return response(404, { message: 'Article not found' });
    }

    // Find the comment index
    const commentIndex = article.Item.comments.findIndex(c => c.id === commentId);
    
    if (commentIndex === -1) {
      return response(404, { message: 'Comment not found' });
    }

    const reply = {
      id: uuidv4(),
      user: user.id,
      username: user.name,
      content,
      createdAt: new Date().toISOString()
    };

    const updateParams = {
      TableName: `Articles-${stage}`,
      Key: { id: articleId },
      UpdateExpression: `SET comments[${commentIndex}].replies = list_append(if_not_exists(comments[${commentIndex}].replies, :empty_list), :reply)`,
      ExpressionAttributeValues: {
        ':reply': [reply],
        ':empty_list': []
      },
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(updateParams).promise();
    
    if (result.Attributes) {
      return response(201, reply);
    }

    return response(500, { message: 'Failed to add reply' });

  } catch (error) {
    console.error('Error adding reply:', error);
    return response(500, { 
      message: 'Error adding reply',
      error: error.message,
      stack: error.stack 
    });
  }
};