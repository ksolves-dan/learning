const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user || user.role !== 'admin') {
      return response(403, { message: 'Not authorized to approve articles' });
    }

    const { id } = event.pathParameters;
    
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      },
      UpdateExpression: 'set isApproved = :a',
      ExpressionAttributeValues: {
        ':a': true
      },
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(params).promise();
    
    if (result.Attributes) {
      const approvedArticle = {
        ...result.Attributes,
        id: result.Attributes.id
      };
      return response(200, approvedArticle);
    } else {
      return response(404, { message: 'Article not found' });
    }
  } catch (error) {
    console.error('Error approving article:', error);
    return response(500, { message: 'Error approving article' });
  }
};