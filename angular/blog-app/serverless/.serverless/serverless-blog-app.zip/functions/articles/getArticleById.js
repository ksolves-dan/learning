const dynamodb = require('../../utils/dynamodb');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const { id } = event.pathParameters;
    
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      }
    };

    const result = await dynamodb.get(params).promise();
    
    if (result.Item) {
      const article = {
        ...result.Item,
        id: result.Item.id
      };
      return response(200, article);
    } else {
      return response(404, { message: 'Article not found' });
    }
  } catch (error) {
    console.error('Error fetching article:', error);
    return response(500, { message: 'Error fetching article' });
  }
};