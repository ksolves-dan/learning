const { v4: uuidv4 } = require('uuid');
const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user) {
      return response(401, { message: 'Not authorized' });
    }

    const { title, description, content, tags } = JSON.parse(event.body);
    const id = uuidv4();

    const article = {
      id,
      id: id,
      title,
      description,
      content,
      tags: tags || [],
      author: user.id,
      isApproved: false,
      comments: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Articles-${stage}`,
      Item: article
    };

    await dynamodb.put(params).promise();
    return response(201, article);
  } catch (error) {
    console.error('Error creating article:', error);
    return response(500, { message: 'Error creating article' });
  }
};