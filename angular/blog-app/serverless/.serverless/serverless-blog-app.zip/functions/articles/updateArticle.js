const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user) {
      return response(401, { message: 'Not authorized' });
    }

    const { id } = event.pathParameters;
    const { title, description, content, tags } = JSON.parse(event.body);
    const stage = process.env.STAGE || 'dev';
    const getParams = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      }
    };

    const result = await dynamodb.get(getParams).promise();
    
    if (!result.Item) {
      return response(404, { message: 'Article not found' });
    }

    if (result.Item.author !== user.id && user.role !== 'admin') {
      return response(403, { message: 'Not authorized to update this article' });
    }
    
    const updateParams = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      },
      UpdateExpression: 'set title = :t, description = :d, content = :c, tags = :tg, updatedAt = :u',
      ExpressionAttributeValues: {
        ':t': title,
        ':d': description,
        ':c': content,
        ':tg': tags || [],
        ':u': new Date().toISOString()
      },
      ReturnValues: 'ALL_NEW'
    };

    const updateResult = await dynamodb.update(updateParams).promise();
    const updatedArticle = {
      ...updateResult.Attributes,
      id: updateResult.Attributes.id
    };
    return response(200, updatedArticle);
  } catch (error) {
    console.error('Error updating article:', error);
    return response(500, { message: 'Error updating article' });
  }
};