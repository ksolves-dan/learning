const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user) {
      return response(401, { message: 'Not authorized' });
    }

    const { id } = event.pathParameters;
    const stage = process.env.STAGE || 'dev';
    const getParams = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      }
    };

    const result = await dynamodb.get(getParams).promise();
    
    if (!result.Item) {
      return response(404, { message: 'Article not found' });
    }

    if (user.role !== 'admin') {
      return response(403, { message: 'Not authorized to delete this article' });
    }
    
    const deleteParams = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      }
    };

    await dynamodb.delete(deleteParams).promise();
    return response(200, { message: 'Article removed' });
  } catch (error) {
    console.error('Error deleting article:', error);
    return response(500, { message: 'Error deleting article' });
  }
};