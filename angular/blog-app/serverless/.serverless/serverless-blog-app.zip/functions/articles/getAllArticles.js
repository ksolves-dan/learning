const dynamodb = require('../../utils/dynamodb');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Articles-${stage}`,
    };

    const result = await dynamodb.scan(params).promise();
    console.log('result',result)
    const articles = result.Items.map(article => ({
      ...article,
      id: article.id
    }));
    console.log('articles',articles)
    return response(200, articles);
  } catch (error) {
    console.error('Error fetching articles:', error);
    return response(500, { message: 'Error fetching articles' });
  }
};