const { v4: uuidv4 } = require('uuid');
const dynamodb = require('../../utils/dynamodb');
const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user) {
      return response(401, { message: 'Not authorized' });
    }

    const { id } = event.pathParameters;
    const { content } = JSON.parse(event.body);

    const comment = {
      id: uuidv4(),
      user: user.id,
      username: user.name,
      content,
      createdAt: new Date().toISOString(),
      replies: []
    };
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Articles-${stage}`,
      Key: {
        id: id
      },
      UpdateExpression: 'SET comments = list_append(if_not_exists(comments, :empty_list), :comment)',
      ExpressionAttributeValues: {
        ':comment': [comment],
        ':empty_list': []
      },
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(params).promise();
    
    if (result.Attributes) {
      return response(201, comment);
    } else {
      return response(404, { message: 'Article not found' });
    }
  } catch (error) {
    console.error('Error adding comment:', error);
    return response(500, { message: 'Error adding comment' });
  }
};