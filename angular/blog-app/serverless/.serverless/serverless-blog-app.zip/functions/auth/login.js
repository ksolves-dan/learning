const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const dynamodb = require('../../utils/dynamodb');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const { email, password } = JSON.parse(event.body);
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Users-${stage}`,
      IndexName: 'EmailIndex',
      KeyConditionExpression: 'email = :email',
      ExpressionAttributeValues: {
        ':email': email
      }
    };

    const result = await dynamodb.query(params).promise();
    const user = result.Items[0];

    if (user && (await bcrypt.compare(password, user.password))) {
      const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, {
        expiresIn: '30d',
      });

      return response(200, {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        token,
      });
    } else {
      return response(401, { message: 'Invalid email or password' });
    }
  } catch (error) {
    console.error('Error in login:', error);
    return response(500, { message: 'Server error' });
  }
};