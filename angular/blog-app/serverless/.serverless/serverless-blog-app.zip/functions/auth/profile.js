const { verifyToken } = require('../../utils/auth');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const token = event.headers.Authorization.split(' ')[1];
    const user = await verifyToken(token);

    if (!user) {
      return response(401, { message: 'Not authorized' });
    }

    // Ensure id is used instead of id
    const { id, name, email, role } = user;
    return response(200, { id, name, email, role });
  } catch (error) {
    console.error('Error in profile:', error);
    return response(500, { message: 'Server error' });
  }
};