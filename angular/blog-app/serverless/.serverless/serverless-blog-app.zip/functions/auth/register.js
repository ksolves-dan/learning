const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const dynamodb = require('../../utils/dynamodb');
const response = require('../../utils/response');

module.exports.handler = async (event) => {
  try {
    const { name, email, password, role } = JSON.parse(event.body);
    const stage = process.env.STAGE || 'dev';
    const userParams = {
      TableName: `Users-${stage}`,
      IndexName: 'EmailIndex',
      KeyConditionExpression: 'email = :email',
      ExpressionAttributeValues: {
        ':email': email
      }
    };

    const existingUser = await dynamodb.query(userParams).promise();
    if (existingUser.Items.length > 0) {
      return response(400, { message: 'User already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const userId = uuidv4();
    const user = {
      id: userId,
      name,
      email,
      password: hashedPassword,
      role: role || 'user',
    };

    const params = {
      TableName: `Users-${stage}`,
      Item: user
    };

    await dynamodb.put(params).promise();

    const token = jwt.sign({ id: userId, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: '30d',
    });

    return response(201, {
      id: userId,
      name: user.name,
      email: user.email,
      role: user.role,
      token,
    });
  } catch (error) {
    console.error('Error in register:', error);
    return response(500, { message: 'Server error', error: error.message });
  }
};