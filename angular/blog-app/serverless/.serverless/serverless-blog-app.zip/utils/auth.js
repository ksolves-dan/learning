const jwt = require('jsonwebtoken');
const dynamodb = require('./dynamodb');

const verifyToken = async (token) => {
  try {
    if (!token) return null;

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const stage = process.env.STAGE || 'dev';
    const params = {
      TableName: `Users-${stage}`,
      Key: {
        id: decoded.id
      }
    };

    const result = await dynamodb.get(params).promise();
    const user = result.Item;

    if (user) {
      delete user.password;
      return user;
    } else {
      return null;
    }
  } catch (error) {
    console.error('Error verifying token:', error);
    return null;
  }
};

module.exports = { verifyToken };
